import os
import subprocess

def read_merchandise():
    with open("merchandise_records.txt", "r") as file:
        merchandise = file.read().splitlines()
    return merchandise

def write_merchandise(merchandise):
    with open("merchandise_records.txt", "w") as file:
        formatted_merchandise = []
        for item in merchandise:
            item_details = item.split(" - RM ")
            product_name = item_details[0]
            product_price = "{:.0f}".format(float(item_details[1]))
            formatted_merchandise.append("{} - RM {}".format(product_name, product_price))
        file.write("\n".join(formatted_merchandise))

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def print_merchandise():
    clear_screen()
    merchandise = read_merchandise()
    print("Merchandise records:")
    print("-" * 45)
    for item in merchandise:
        item_details = item.split(" - RM ")
        product_name = item_details[0]
        product_price = float(item_details[1]) / 100  # Divide by 100 to convert to RM.xx format
        print("{:<30} - RM {:<10.2f}".format(product_name, product_price))
        print()  # Add an empty line between items
    print("-" * 45)

def remove_item():
    while True:
        print("")
        remove_item = input("Enter the name of the product to remove (Enter 'Q' to exit): ")
        if remove_item.lower() == "q":
           subprocess.run(["python", "homepage_admin.py"])
           break
        merchandise = read_merchandise()
        found = False
        updated_merchandise = []
        for item in merchandise:
            item_details = item.split(" - RM ")
            product_name = item_details[0]
            if product_name.lower() == remove_item.lower():
                found = True
            else:
                updated_merchandise.append(item)
        if found:
            write_merchandise(updated_merchandise)
            clear_screen()
            print("Product removed successfully.")
            print("")
            add_new = input("Do you want to add a new item? (Enter 'Y' for Yes, 'N' for No): ")
            if add_new.lower() == "y":
                clear_screen()
                add_item()
            break
        else:
            print("")
            print("Product not found. Please enter a valid product name.")

def add_item():
    while True:
        print("")
        new_item = input("Enter a new product (Enter 'K' to display updated record, Enter 'Q' to exit): ")
        if new_item.lower() == "k":
            print_merchandise()
        elif new_item.lower() == "q":
            subprocess.run(["python", "homepage_admin.py"])
            break
        else:
            merchandise = read_merchandise()
            new_id = str(len(merchandise) + 1)
            print("")
            new_price = input("Enter the price of the product (e.g., 15.00): ")
            try:
                new_price = "{:.2f}".format(float(new_price) * 100)  # Multiply by 100 to adjust for decimal places
                new_record = "{} - RM {}".format(new_item, new_price)
                merchandise.append(new_record)
                write_merchandise(merchandise)
                print("")
                print("Product added successfully.")
            except ValueError:
                print("Invalid price format. Please enter a valid price.")

clear_screen()

while True:
    clear_screen()
    print_merchandise()
    print("")
    action = input("Enter 'R' to remove a product, Enter 'C' to continue: ")

    if action.lower() == "r":
        remove_item()

    display_option = input("Enter 'K' to display updated record, Enter 'C' to continue, or Enter 'Q' to exit: ")

    if display_option.lower() == "k":
        clear_screen()
        print_merchandise()

    if display_option.lower() == "q":
        subprocess.run(["python", "homepage_admin.py"])
        break

    if display_option.lower() == "c":
        add_new = input("Do you want to add a new item? (Enter 'Y' for Yes, 'N' for No): ")
        if add_new.lower() == "y":
            clear_screen()
            add_item()
            break

clear_screen()
