import os
import subprocess

def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)

clear_terminal()
def begin2():
    print("WELCOME TO STARGAZE CINEMA!!!")
    print("==============================")
    print("")
    print("1. Movie records")
    print("2. Merchandise records")
    print("3. Customer records")
    print("4. Review records")
    print("D. Delete account")
    print("O. Log out")

    try:
        print("")
        opt = input("(1/2/3/4/D/O) --> ")
        if opt not in ["1", "2", "3", "4", "D", "O"]:
            print("\n!! Please enter a valid option!!\n")
            begin2()
        else:
            access3(opt)
    except ValueError:
        print("\n!! Please enter valid input!!\n")
        begin2()


def access3(opt):
    if opt == "1":
        clear_terminal()
        print("Movie records selected")
        subprocess.run(["python","movie records.py"])
        begin2()
    elif opt == "2":
        clear_terminal()
        print("Merchandise records selected")
        subprocess.run(["python","merchandise records.py"])
        begin2()
    elif opt == "3":
        clear_terminal()
        print("Customer records selected")
        subprocess.run(["python","customer records.py"])
        begin2()
    elif opt == "4":
        clear_terminal()
        print("Review records selected")
        subprocess.run(["python","review records.py"])
    elif opt == "D":
        clear_terminal()
        print("***Delete account selected***")
        clear_terminal()
        delete_account()
    elif opt == "O":
        clear_terminal()
        log_out()
        


def delete_account():
    confirmation = input("Are you sure you want to delete your account? (Y/N) ---> ")
    if confirmation.upper() == "Y":
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        if confirm_credentials(username,password):
            delete_user_data(username)
            print("Account deleted successfully")
            return subprocess.run(["python", "f1.py"])
        else:
            print("Incorrect username or password. Account deletion failed.")
            begin2()
    else:
        print("Account deletion canceled")
        begin2()


def confirm_credentials(username, password):
    with open("admin_details.txt", "r") as file:
        for line in file:
            user_data = line.strip().split(",")
            if len(user_data) == 2:
                stored_username = user_data[0].strip()
                stored_password = user_data[1].strip()
                if stored_username == username and stored_password == password:
                    return True
        return False




def delete_user_data(username):
    with open("admin_details.txt", "r") as file:
        lines = file.readlines()
    with open("admin_details.txt", "w") as file:
        for line in lines:
            user_data = line.strip().split(",")
            if len(user_data) == 2 and user_data[0] != username:
                file.write(line)



def log_out():
    confirmation = input("Are you sure you want to log out? (Y/N) ---> ")
    if confirmation.upper() == "Y":
        print("Log out successful")
        return subprocess.run(["python", "f1.py"])

    else:
        begin2()


begin2()


    