import os

def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)

def display_customer_records():
    try:
        with open("customer_records.txt", "r") as file:
            records = file.readlines()
            if records:
                clear_terminal()
                print("***Customer Records***")
                print("========================"+"\n")
                for record in records:
                    print(record.strip())
            else:
                print("No customer records found.")
    except IOError:
        print("An error occurred while accessing customer records.")

# Call the function to display the customer records
display_customer_records()



def main():
    while True:
        print("")
        user_input = input("Enter 'Q' to quit: ")
        if user_input.lower() == 'q':
            clear_terminal()
            break
        else:
            # Perform any other actions or operations here
            print(f"You entered: {user_input}")

if __name__ == "__main__":
    main()