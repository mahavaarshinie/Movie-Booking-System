import os
import datetime

class Movie:
    def __init__(self, name, screening_dates, total_seats):
        self.name = name
        self.screening_dates = screening_dates
        self.seat_availability = {date: ["A1", "A2", "A3", "A4", "A5", "A6", "B1", "B2", "B3", "B4", "B5", "B6",
                                         "C1", "C2", "C3", "C4", "C5", "C6", "D1", "D2", "D3", "D4", "D5", "D6"] for date in screening_dates}
        self.date = None
        self.time = None
    def update_seat_availability(self, date, time, booked_seats):
        if date in self.screening_dates:
            if time == "10:30 AM":
                self.seat_availability[date] = [seat if seat not in booked_seats else " " for seat in self.seat_availability[date]]


class TicketBookingSystem:
    def __init__(self):
        self.movies = []

    def add_movie(self, movie):
        self.movies.append(movie)

    def search_movie_by_name(self, movie_name):
        for movie in self.movies:
            if movie.name == movie_name:
                return movie
        return None

    def search_movie_by_date(self, date):
        matching_movies = []
        for movie in self.movies:
            if date in movie.screening_dates:
                matching_movies.append(movie)
        return matching_movies

    def display_movies(self):
        print("Available movies:")
    with open("movie_records.txt", "r") as file:
        movies = file.read().splitlines()

    for movie in movies:
        print(movie)


    def update_seat_availability(self):
       # Read booking details from file and update seat availability
       with open("customer_records.txt", "r") as file:
        bookings = file.readlines()

        for line in bookings:
          if line.startswith("Movie:"):
            movie_name = line.strip().split(": ")[1]
          elif line.startswith("Date:"):
            date = line.strip().split(": ")[1]
          elif line.startswith("Time:"):
            time = line.strip().split(": ")[1]
          elif line.startswith("Seats:"):
            seats = line.strip().split(": ")[1].split(", ")
            for movie in self.movies:
                if movie.name == movie_name:
                    movie.update_seat_availability(date, time, seats)
                    
                    

    def book_ticket(self, movie, date, time, seats):
        # Check seat availability
        if any(seat not in movie.seat_availability[date] for seat in seats):
            print("Selected seats are not available. Please choose different seats.")
            return

        # Proceed with booking
        clear_terminal()

        print("******Booking details*****")
        print(" ")
        print("Movie: " + movie.name)
        print("Date: " + date)
        print("Time: " + time)
        print("Seats: " + ', '.join(seats))
        

        # Calculate the total price based on the number of seats
        num_seats = len(seats)
        num_children = input("Enter the number of children (max " + str(num_seats) + "): ")
        while not num_children.isdigit() or int(num_children) > num_seats:
            print("Invalid number of children. Please enter a valid number.")
            num_children = input("Enter the number of children (max " + str(num_seats) + "): ")
        num_adults = num_seats - int(num_children)

        total_price = (12 * int(num_children)) + (18 * int(num_adults))
        print("Total Price: RM" + str(total_price))

        payment = input("Would you like to make a payment? (Y/N): ")
        if payment.upper() == "Y":
            clear_terminal()
            print("========================")
            print("Payment done. Thank you!!")
            print("Your order has been sent successfully.")
            print("========================")
        else:
            print("Payment not completed.")
        
    
        print("*****Movie Ticket*****")
        print("+" + "-" * 33 + "+")
        print("| {:<18} | {:<10} |".format("Full name", full_name))
        print("| {:<18} | {:<10} |".format("Movie", movie_name))
        print("| {:<18} | {:<10} |".format("Date", date))
        print("| {:<18} | {:<10} |".format("Time", time))
        print("| {:<18} | {:<10} |".format("Seats", ', '.join(seats)))
        print("| {:<18} | {:<10} |".format("Number of Children", str(num_children)))
        print("| {:<18} | {:<10} |".format("Number of Adults", str(num_adults)))
        ticket_number = movie.name.replace(" ", "") + date.replace("-", "") + time.replace(":", "")
        print("+" + "-" * 33 + "+")

        # Save the booking details to the file
        with open("customer_records.txt", "a") as file:
            file.write("Full name: " + full_name + "\n")
            file.write("Movie: " + movie.name + "\n")
            file.write("Date: " + date + "\n")
            file.write("Time: " + time + "\n")
            file.write("Seats: " + ', '.join(seats) + "\n")
            file.write("Number of Children: " + str(num_children) + "\n")
            file.write("Number of Adults: " + str(num_adults) + "\n")
            file.write("Total Price: RM" + str(total_price) + "\n")
            file.write("Ticket number: " + ticket_number + "\n" )
            file.write("---------------------------------------\n")

        # Update seat availability
        movie.seat_availability[date] = [seat if seat not in seats else " " for seat in movie.seat_availability[date]]


with open("user_details.txt", "r") as file:
    line = file.readline().strip()
    full_name = line.split(",")[0]


def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)

def collect_feedback(username):
    print("Please rate our service (from 1 to 5, with 5 being the highest).")

    # Collect rating from the user
    while True:
        rating = input("Enter your rating: ")
        if rating.isdigit() and 1 <= int(rating) <= 5:
            break
        else:
            print("Invalid rating. Please enter a number between 1 and 5.")

    with open("review_records.txt", "a") as file:
        file.write("Username: " + username + "\n")
        file.write("Rating: " + rating + "\n")
        file.write("-----------------------------------\n")
        
def get_day_name(date_string):
    clear_terminal()
    date = datetime.datetime.strptime(date_string, "%d-%m")
    return date.strftime("%A")

# Provided dates
dates = ["17-08", "18-08", "19-08", "20-08"]

# Create a list of day and date pairs
day_date_pairs = [(get_day_name(date), date) for date in dates]

# Calculate the maximum length of day and date strings
max_day_length = max(len(pair[0]) for pair in day_date_pairs)
max_date_length = max(len(pair[1]) for pair in day_date_pairs)

# Header row
header = "Day" + " " * (max_day_length - 3) + " | Date"

# Separator row
separator = "-" * (max_day_length + max_date_length + 3)

# Table rows
rows = [day.ljust(max_day_length) + " | " + date for (day, date) in day_date_pairs]

# Print the table
print("==========================")
print("   Movie ticket booking")
print("==========================")
print("")
print("")
print(header)
print(separator)
for row in rows:
    print(row)


ticket_booking_system = TicketBookingSystem()
movie_names = []
with open("movie_records.txt", "r") as file:
    movie_records = file.read().splitlines()
for record in movie_records:
    movie_name = record.strip()
    movie_names.append(movie_name)


# Create movies and add them to the ticket booking system
movies = []
for movie_name in movie_names:
    movies.append(Movie(movie_name, ["17-08", "18-08", "19-08", "20-08"], 10))  

for movie in movies:
    ticket_booking_system.add_movie(movie)

# Update seat availability based on bookings
ticket_booking_system.update_seat_availability()

# Search movie by date
print(" ")
print("Search movies by screening date: 17-08, 18-08, 19-08, 20-08")
print(" ")
date = input("Enter screening date (DD-MM): ")
matching_movies = ticket_booking_system.search_movie_by_date(date)
if matching_movies:
    clear_terminal()
    print("Available movies!")
    print(" ")
    for movie in matching_movies:
        print("- " + movie.name)
else:
    print("No movies found on the given date.")

# Search movie by name
print(" ")
movie_name = input("Enter movie name: ")
found_movie = ticket_booking_system.search_movie_by_name(movie_name)
while not found_movie:
    print("Movie not found! Please choose from the available movies:")
    ticket_booking_system.display_movies()
    movie_name = input("Enter movie name: ")
    found_movie = ticket_booking_system.search_movie_by_name(movie_name)

print("-----------------------------------------------------")
print("-----------------------------------------------------")

# Choose movie, date, time, and seats for booking
if found_movie:
    clear_terminal()
print("Choose screening time:")
print(" ")
print("--------------------------")
print("|    Day    |    Night   |")
print("--------------------------")
print("|  10:30 AM |  9:30 PM   |")
print("|  1:00 AM  |  11:00 PM  |")
print("--------------------------")
print("")
time = input("Enter screening time(E.G. 10:30 AM): ")

    # Check if the entered screening time is valid
valid_screening_times = ["10:30 AM", "1:00 AM", "9:30 PM", "11:00 PM"]
while time not in valid_screening_times:
        print("Invalid screening time! Please try again.")
        time = input("Enter screening time: ")
      

while True:
        clear_terminal()
        print("Choose seat number:")
        print(" ")
        # Display the seating layout
        nestedList = [["A1", "A2", "A3", "A4", "A5", "A6"],
                      ["B1", "B2", "B3", "B4", "B5", "B6"],
                      ["C1", "C2", "C3", "C4", "C5", "C6"],
                      ["D1", "D2", "D3", "D4", "D5", "D6"]]

        print("   S   C   R   E   E   N  ")
        for item in nestedList:
            row = "|"
            for seat in item:
                if seat not in found_movie.seat_availability[date]:
                    row += "|   "
                else:
                    row += "|" + seat + "|"
            print(row + "|")
            print(" ")

        seats = input("Enter seats (separated by comma): ").split(',')
        

        # Check if the entered seat numbers are valid and available
        valid_seat_numbers = ["A1", "A2", "A3", "A4", "A5", "A6", "B1", "B2", "B3", "B4", "B5", "B6", "C1", "C2", "C3",
                              "C4", "C5", "C6", "D1", "D2", "D3", "D4", "D5", "D6"]
        invalid_seats = [seat for seat in seats if seat not in valid_seat_numbers or seat not in found_movie.seat_availability[date]]
        while invalid_seats:
            print("Invalid or unavailable seats:", ', '.join(invalid_seats))
            seats = input("Enter seats (separated by comma): ").split(',')
            invalid_seats = [seat for seat in seats if seat not in valid_seat_numbers or seat not in found_movie.seat_availability[date]]

        ticket_booking_system.book_ticket(found_movie, date, time, seats)
        print(" ")
        another_booking = input("Do you want to book another ticket for the same movie, date, and time? (Y/N): ")
        if another_booking.upper() == "N":
            break

    # Create a dummy ticket object for feedback
class Ticket:
        def __init__(self, movie):
            self.movie = movie

ticket = Ticket(found_movie)
    
clear_terminal()
feedback = input("Would you like to rate us? (Y/N): ")
if feedback.upper() == "Y":
    with open("user_details.txt", "r") as file:
        line = file.readline().strip()
        username = line.split(",")[1].strip()  

    collect_feedback(username)
    clear_terminal()
    print("=============================")
    print("Thank you for your rating!")
    print("=============================")
