import os
import subprocess

def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)
clear_terminal()
def begin():
    print("WELCOME TO STARGAZE CINEMA!!!")
    print("==============================")
    print("")
    print("1. Movie ticket booking")
    print("2. Grab your favourite")
    print("3. Parking ticket booking")
    print("D. Delete account")
    print("O. Log out")

    try:
        print(" ")
        opt = input("(1/2/3/D/O) --> ")
        if opt not in ["1", "2", "3", "D", "O"]:
            print("\n!! Please enter a valid option!!\n")
            return begin()
        else:
            access(opt)
    except ValueError:
        print("\n!! Please enter valid input!!\n")
        return begin()


def access(opt):
    if opt == "1":
        clear_terminal()
        print(" ")
        subprocess.run(["python", "mtb.py"])
        begin()
    elif opt == "2":
        clear_terminal()
        print(" ")
        subprocess.run(["python", "merchandise purchase.py"])
        begin()
    elif opt == "3":
        clear_terminal()
        print(" ")
        subprocess.run(["python", "parking booking.py"])
    elif opt == "D":
        clear_terminal()
        print("***Delete account selected***")
        print(" ")
        delete_account()
    elif opt == "O":
        clear_terminal()
        log_out()
    else:
        print("\n!! Please enter a valid option!!\n")
        


def delete_account():
    confirmation = input("Are you sure you want to delete your account? (Y/N) ---> ")
    if confirmation.upper() == "Y":
        clear_terminal()
        username = input("Enter your username: ")
        password = input("Enter your password: ")

        if confirm_credentials(username, password):
            delete_user_data(username)
            clear_terminal()
            print("=============================")
            print("Account deleted successfully")
            print("=============================")
            return subprocess.run(["python", "f1.py"])

        else:
            clear_terminal()
            print("Incorrect username or password. Account deletion failed.")
            print("=========================================================")
            begin()
    else:
        print("Account deletion canceled")
        begin()


def confirm_credentials(username, password):
    with open("user_details.txt", "r") as file:
        for line in file:
            user_data = line.strip().split(",")
            if len(user_data) == 4 and user_data[1] == username and user_data[2] == password:
                return True
    return False


def delete_user_data(username):
    with open("user_details.txt", "r") as file:
        lines = file.readlines()
    with open("user_details.txt", "w") as file:
        for line in lines:
            user_data = line.strip().split(",")
            if len(user_data) == 4 and user_data[1] != username:
                file.write(line)


def log_out():
    confirmation = input("Are you sure you want to log out? (Y/N) ---> ")
    if confirmation.upper() == "Y":
      clear_terminal()
      print("========================")
      print("Logged out successfully")
      print("========================")
      return subprocess.run(["python", "f1.py"])

    
    else:
        begin()


begin()