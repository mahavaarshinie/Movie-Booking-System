import os
import re
from datetime import datetime

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def merchandise_purchase():
    clear_screen()
    print("\nGrab your favorites!\n")
    input("Press Enter to continue...")  # Wait for user to press Enter before proceeding

    display_merchandise()
    purchase_item()

def display_merchandise():
    clear_screen()
    merchandise_records = read_merchandise_records()

    print("\nMerchandise Available:\n")
    print("{:<20} {:<10}".format("Item", "Price"))
    print("-" * 30)
    
    for item, price in merchandise_records.items():
        formatted_price = "RM {:.2f}".format(price / 100) if price > 0 else "RM 0.00"
        print("{:<20} {:<10}".format(item, formatted_price))

def read_merchandise_records():
    merchandise_records = {}

    with open("merchandise_records.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            match = re.match(r"(.+)\s-\sRM\s([\d.]+)", line)
            if match:
                item = match.group(1)
                price = float(match.group(2))
                merchandise_records[item] = price

    return merchandise_records

def purchase_item():
    clear_cart()  # Empty the cart before starting a new purchase

    while True:
        item_choice = input("\nEnter the item you want to add to the cart: ")

        merchandise_records = read_merchandise_records()

        if item_choice in merchandise_records:
            quantity = int(input("Enter the quantity: "))
            item_price = merchandise_records[item_choice]

            # Add item with quantity to the cart
            with open("cart.txt", "a") as file:
                for _ in range(quantity):
                    file.write(item_choice + "\n")
            print("")
            input("Item added to cart successfully! Enter to continue.")
            view_cart()

            print("\n1. Buy now")
            print("Q. Quit")

            option = input("\nSelect an option: ")

            if option.lower() == "q":
                clear_screen()
                print("Thank you for shopping with Stargaze Cinema!")
                break  # Exit the loop and end the purchase process

            if option == "1":
                # Retrieve customer details from the text file
                with open("user_details.txt", "r") as file:
                     line = file.readline().strip()
                     full_name, username, password, contact_number = line.split(",")

                # Prompt the customer to input their address details
                clear_screen()
                address_details = input("Enter your address: ")

                # Prompt the customer to input their email address
                email_address = input("Enter your email address: ")

                full_address = f"{address_details}"
                delivery_fee = 400  # Set the default delivery fee to 400

                formatted_item_price = "RM {:.2f}".format(item_price / 100) if item_price > 0 else "RM 0.00"
                formatted_delivery_fee = "RM {:.2f}".format(delivery_fee / 100) if delivery_fee > 0 else "RM 0.00"
                total_price = (item_price * quantity) + delivery_fee  # Calculate total price based on quantity
                formatted_total_price = "RM {:.2f}".format(total_price / 100)  # Format the total price as "RM 00.00"

                clear_screen()
                print("Thank you for your purchase! ")
                print("Order Details:")
                print("===================================")
                print("Date: {}".format(datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
                print("Name: {}".format(full_name))
                print("Item: {}".format(item_choice))
                print("Price per item:    RM {:.2f}".format(item_price / 100) if item_price > 0 else "RM 0.00")
                print("Quantity:          {}".format(quantity))
                print("Delivery Fee:      RM {:.2f}".format(delivery_fee / 100) if delivery_fee > 0 else "RM 0.00")
                print("Total Subtotal:    {}".format(formatted_total_price))
                print("Contact Number:    {}".format(contact_number))
                print("Email Address:     {}".format(email_address))
                print("===================================")

                # Display "ORDER DELIVERED SUCCESSFULLY!" message
                print("\nORDER DELIVERED SUCCESSFULLY!")

                # Save customer details with the updated email address
                customer_details = {
                    "Name": full_name,
                    "Contact Number": contact_number,
                    "Address": address_details,
                    "Item" : item_choice,
                    "Price per item" : formatted_item_price,
                    "Quantity" : quantity,
                    "Delivery Fee" : formatted_delivery_fee,
                    "Total Subtotal" : formatted_total_price,
                    "Email Address" : email_address,
                }

                write_customer_details(customer_details)

                leave_review = input("\nWould you like to rate us? (Y/N): ").lower()
                if leave_review == "y":
                    write_review(item_choice, username)

                    # Clear the cart after completing the purchase
                    open("cart.txt", "w").close()

                    break  # Exit the loop after completing the purchase
                else:
                    print("Invalid option.")

    while True:
        repurchase = input("\nDo you want to continue shopping? (Y/N): ")
        if repurchase.lower() == "y":
            display_merchandise()
            purchase_item()
            break
        elif repurchase.lower() == "n":
            clear_screen()
            print("Thank you for shopping with Stargaze Cinema!")
            print("============================================")
            print("")
            print("")
            break
        else:
            print("Invalid input. Please enter 'yes' or 'no'.")

def clear_cart():
    open("cart.txt", "w").close()

def user_details(name, username, contact_number, email_address, address_details, unit_number, postcode, state):
    with open("user_details.txt", "w") as file:
        file.write("Name: {}\n".format(name))
        file.write("Username: {}\n".format(username))
        file.write("Contact Number: {}\n".format(contact_number))
        file.write("Email Address: {}\n".format(email_address))
        file.write("Address: {}\n".format(address_details))

def view_cart():
    clear_screen()
    print("Your Cart:")
    with open("cart.txt", "r") as file:
        items = file.readlines()
        if len(items) == 0:
            print("Your cart is empty.")
        else:
            print("{:<10} {:<20}".format("Item", "Quantity"))
            print("-" * 30)
            for item in items:
                item = item.strip()
                print("{:<10} {:<20}".format(item, "1"))  

def read_customer_details():
    customer_details = {}

    with open("customer_records.txt", "r") as file:
        lines = file.readlines()
        for line in lines:
            key, value = line.strip().split(": ")
            customer_details[key] = value

    return customer_details

def write_customer_details(customer_details):
    with open("customer_records.txt", "a") as file: 
        for key, value in customer_details.items():
            file.write("{}: {}\n".format(key, value))
        file.write("---------------------------------------\n")


def write_review(item, name):
    clear_screen()
    print("Please rate our service (from 1 to 5, with 5 being the highest).")
    rating = input("Enter your rating:")

    with open("review_records.txt", "a") as file:
        file.write("Name: {}\n".format(name))
        file.write("Rating: {}\n".format(rating))
        file.write("-----------------------------------\n")

        clear_screen()
    print("=============================")
    print("Thank you for your rating!")
    print("=============================")
    input("Press Enter to continue...")  # Wait for user to press Enter before proceeding

def main():
    merchandise_purchase()

if __name__ == "__main__":
    main()