import os

def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)
clear_terminal()

def read_reviews():
    with open("review_records.txt", "r") as file:
        reviews = file.read().splitlines()
    return reviews

def write_reviews(reviews):
    with open("review_records.txt", "w") as file:
        file.write("\n".join(reviews))

def print_reviews():
    reviews = read_reviews()
    print("***Review records***")
    print("=====================")
    print("")
    for review in reviews:
        print(review)

def add_review():
    while True:
        print("")
        reviewer = input("(Enter 'Q' to exit): ")
        if reviewer.lower() == "q":
            clear_terminal()
            break
        review = input("Enter the movie review: ")
        new_review = f"{reviewer} : {review}"
        reviews = read_reviews()
        reviews.append(new_review)
        write_reviews(reviews)
        print("Review added successfully.")


print("")

print_reviews()
add_review()

print("Thank you for using Stargaze Cinema!")
