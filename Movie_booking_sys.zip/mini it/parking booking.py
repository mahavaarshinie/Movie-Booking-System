import re
import os
from builtins import input

def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)
    

class ParkingBookingSystem:
    def __init__(self):
        self.available_lots = {}
        self.booked_lots = {}
        self.reviews = {}
        for level in range(1, 6):
            self.available_lots[level] = [lot for lot in range(1, 11)]
        self.load_booked_lots()
        if self.booked_lots:
            self.booking_number = max(self.booked_lots.values(), key=lambda x: x['Booking Number'])['Booking Number'] + 1
        else:
            self.booking_number = 1

    def validate_vehicle_number(self, vehicle_number):
        pattern = r"^[A-Za-z]{1,3}\d{1,4}$"
        return re.match(pattern, vehicle_number) is not None
    
    def get_user_details(self, username):
        users = self.read_user_data()
        return users.get(username, {})

    def load_booked_lots(self):
        self.booked_lots = {}  # Clear the existing booked lots
        try:
            with open("parking_records.txt", "r") as file:
                lines = file.readlines()
                for i in range(0, len(lines), 5):
                    booking_number = int(lines[i].split(": ")[1].strip())
                    level, lot = map(int, re.findall(r'\d+', lines[i + 1]))
                    vehicle_number = lines[i + 2].split(": ")[1].strip()
                    vehicle_color = lines[i + 3].split(": ")[1].strip()
                    self.booked_lots[(level, lot)] = {
                        'Booking Number': booking_number,
                        'Vehicle Number': vehicle_number,
                        'Vehicle Color': vehicle_color
                    }
        except FileNotFoundError:
            pass

    def save_booked_lots(self):
        with open("parking_records.txt", "a") as file:
            for lot_choice, details in self.booked_lots.items():
                file.write("Booking Number: " + str(details['Booking Number']) + "\n")
                file.write("Lot: Level " + str(lot_choice[0]) + " Lot " + str(lot_choice[1]) + "\n")
                file.write("Vehicle Number: " + details['Vehicle Number'] + "\n")
                file.write("Vehicle Color: " + details['Vehicle Color'] + "\n")
                file.write("---------------------------\n")

    def book_lot(self):
        print("")
        print("============================================")
        print("----- STARGAZE CINEMA Parking Booking -----")
        print("============================================")
        print("")
        while True:
            level = input("Enter the level number: ")
            if level.isdigit() and 1 <= int(level) <= 5:
                break
            else:
                print("Invalid level number. Please enter a number from 1 to 5.")

        while True:
            lot = input("Enter the lot number: ")
            if lot.isdigit() and int(lot) in self.available_lots[int(level)]:
                break
            else:
                print("Invalid lot number. Please try again.")

        vehicle_number = input("Enter the vehicle number: ")
        while not self.validate_vehicle_number(vehicle_number):
            print("Invalid vehicle number. Please enter a vehicle number with 1-3 alphabets and 1-4 numbers.")
            vehicle_number = input("Enter the vehicle number: ")

        vehicle_color = input("Enter the vehicle color: ")

        self.available_lots[int(level)].remove(int(lot))
        booking_number = self.booking_number
        self.booked_lots[(int(level), int(lot))] = {
            'Booking Number': booking_number,
            'Vehicle Number': vehicle_number,
            'Vehicle Color': vehicle_color,
        }
        clear_terminal()
        print("***Booking successful***\n")
        self.print_receipt((int(level), int(lot)))
        self.display_lot_table()  # Display the updated table
        self.save_booked_lots()

        self.booking_number += 1


    def collect_feedback(self, username):
        print("Please rate our service (from 1 to 5, with 5 being the highest).")

        # Collect rating from the user
        while True:
            rating = input("Enter your rating: ")
            if rating.isdigit() and 1 <= int(rating) <= 5:
                break
            else:
                print("Invalid rating. Please enter a number between 1 and 5.")

        with open("review_records.txt", "a") as file:
            file.write("Username: " + username + "\n")
            file.write("Rating: " + rating + "\n")
            file.write("-----------------------------------\n")

    def display_lot_table(self):
        print("----- Parking Lot Status -----")
        print("===============================")
        print("")
        print("-" * 160)  # Add a partition line before the table
        for level in range(1, 6):
            row = []
            for lot in range(1, 11):
                if (level, lot) in self.booked_lots:
                    row.append("Booked")
                else:
                    row.append(f"Level {level} Lot {lot}")
            print(" | ".join(row))
            print("-" * 160)  # Add a partition line after each row
        print()
        print("-" * 160)  # Add a partition line after the table
        print()

    def print_receipt(self, lot_choice):
        booking_details = self.booked_lots[lot_choice]
        username = ""
        
        with open("user_details.txt", "r") as file:
            line = file.readline().strip()
            name, username, password, phone_number = line.split(",")
            

        print("----- Parking Receipt -----")
        print("")
        print(f"Name: {name}")
        print(f"Booking Number: {booking_details['Booking Number']}")
        print(f"Lot: Level {lot_choice[0]} Lot {lot_choice[1]}")
        print(f"Vehicle Number: {booking_details['Vehicle Number']}")
        print(f"Vehicle Color: {booking_details['Vehicle Color']}")
        print("---------------------------\n")
        input("Press enter to continue...")
        clear_terminal()

        with open("customer_records.txt", "a") as file:
            file.write("Name: " + name + "\n")
            file.write("Booking Number: " + str(booking_details['Booking Number']) + "\n")
            file.write("Lot: Level " + str(lot_choice[0]) + " Lot " + str(lot_choice[1]) + "\n")
            file.write("Vehicle Number: " + booking_details['Vehicle Number'] + "\n")
            file.write("Vehicle Color: " + booking_details['Vehicle Color'] + "\n")
            file.write("---------------------------------------\n")

    def run(self):
        clear_terminal()
        print("----- Parking Booking System -----")
        print("")
        while True:
            
            print("1. Book a parking lot")
            print("2. Exit")
            print("")

            choice = input("Enter your choice: ")

            if choice == "1":
                clear_terminal()
                self.display_lot_table()
                self.book_lot()
            elif choice == "2":
                break
            else:
                print("Invalid choice. Please try again.")


        clear_terminal()
        feedback = input("Would you like to rate us? (Y/N): ")
        print("")
        if feedback.upper() == "Y":
            with open("user_details.txt", "r") as file:
                line = file.readline().strip()
                name, username, password, phone_number = line.split(",")

            self.collect_feedback(username)
            clear_terminal()
            print("Thank you for your rating!")
        clear_terminal()
        print("Thank you for using the Parking Booking System. Come again later!")


if __name__ == "__main__":
    parking_system = ParkingBookingSystem()
    parking_system.run()

