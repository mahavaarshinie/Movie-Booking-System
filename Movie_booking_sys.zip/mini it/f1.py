import os
import re
import subprocess


def clear_terminal():
    command = "cls" if os.name == "nt" else "clear"
    os.system(command)


def read_user_data():
    users = {}
    try:
        with open('user_details.txt', 'r') as file:
            lines = file.readlines()
            for line in lines[::-1]:
                full_name, username, password, phone_number = line.strip().split(",")
                users[username] = {'full_name': full_name, 'password': password, 'phone_number': phone_number}
    except IOError:
        print("An error occurred while accessing user details. Please try again.")
        return {}
    return users

def write_user_data(users):
    try:
        with open('user_details.txt', 'w') as file:
            for username, user_info in reversed(users.items()):
                full_name = user_info['full_name']
                password = user_info['password']
                phone_number = user_info['phone_number']
                file.write(f"{full_name},{username},{password},{phone_number}\n")
    except IOError:
        print("An error occurred while accessing user details. Please try again.")


def read_admin_data():
    admins = {}
    try:
        with open('admin_details.txt', 'r') as file:
            for line in file:
                username, password = line.strip().split(",")
                admins[username.strip()] = password.strip()
    except IOError:
        print("An error occurred while accessing admin details. Please try again.")
        return {}
    return admins

def write_admin_data(admins):
    try:
        with open('admin_details.txt', 'w') as file:
            for username, password in admins.items():
                file.write(f"{username},{password}\n")
    except IOError:
        print("An error occurred while accessing admin details. Please try again.")

def start():
        clear_terminal()
        print("==============================")
        print(" Welcome TO STARGAZE CINEMA!!! ")
        print("==============================")

        print("What do you want to do?")
        print("1. Sign up (for new customers)")
        print("2. Login (for returning customers)")
        print("3. Admin login (for authorized users)")

        try:
            print(" ")
            opt = (input("(1/2/3) --> "))
            if opt not in ["1", "2", "3"]:
                print("\n!!Please enter a valid option!!\n")
                return start()
            else:
                access2(opt)
        except ValueError:
            print("\n!!Please enter valid input!!\n")
            return start()


def sign_up():
    clear_terminal()
    print("========== SIGN UP ==========")
    full_name = input("Enter your full name: ")
    if not check_name_format(full_name):
        print("Invalid full name. Please enter a valid name.")
        return sign_up()
    
    name = input("Enter your username: ")
    print("*** Your password must contain more than 5 and less than 10 characters with at least one capital letter and number. ***")
    password = input("Enter your password: ")
    phone_number = input("Enter your phone number: ")
    if not check_phone_number_format(phone_number):
        print("Invalid phone number. Please enter a valid number.")
        return sign_up()

    # Validate password requirements
    if not check_password_requirements(password):
        print("Please try again with a valid password.")
        return sign_up()

    if name.strip() == "" or password.strip() == "" or phone_number.strip() == "":
        print("\n!!! Please enter all the required information !!!\n")
        return sign_up()

    try:
        users = read_user_data()
        users[name] = {'full_name': full_name, 'password': password, 'phone_number': phone_number}
        write_user_data(users)
        clear_terminal()
        print("\nRegistered Successfully!")
        print("-------------------------")
        print("Welcome", full_name)
        print("Username:", name)
        print("-------------------------")

        change_password_prompt(name, password)
    except IOError:
        print("An error occurred while accessing user details. Please try again.")
        return start()

def check_name_format(full_name):
    # Check for numbers and symbols in the full name
    if re.search(r'[0-9!@#$%^&*(),.?":{}|<>]', full_name):
        return False
    return True

def check_phone_number_format(phone_number):
    # Check for letters and symbols in the phone number
    if re.search(r'[a-zA-Z!@#$%^&*(),.?":{}|<>]', phone_number):
        return False
    return True

def change_password(username, current_password, new_password):
    users = read_user_data()

    if username in users and users[username]['password'] == current_password:
        users[username]['password'] = new_password
        write_user_data(users)
        clear_terminal()
        print("Password changed successfully.")
        print("===================================")
    else:
        print("Invalid username or password.")
        print("===================================")

def change_password_prompt(username, current_password, admin=False):
    print("\nDo you want to change your password?")
    answer = input("Enter 'Y' or 'N': ")
    if answer.upper() == 'Y':
        clear_terminal()
        password = input("Enter your old password: ")
        if password != current_password:
            print("Incorrect old password.")
            print("Password change is unsuccessful!!")
            return start()
        print("")
        print("*** Your password must contain more than 5 and less than 10 characters with at least one capital letter and number. ***")
        print(" ")
        new_password = input("Enter your new password: ")
        if not check_password_requirements(new_password):
            print("Please try again with a valid password.")
            return change_password_prompt(username, current_password, admin=admin)

        if admin:
            change_admin_password(username, current_password, new_password)
        else:
            change_password(username, current_password, new_password)
    elif answer.upper() == 'N':
        clear_terminal()

    else:
        print("Invalid input. Please enter 'Y' or 'N'.")
        return change_password_prompt(username, current_password, admin=admin)

def check_password_requirements(password):
    # Check for at least one capital letter
    if not re.search(r'[A-Z]', password):
        print("Password must contain at least one capital letter!")
        return False

    # Check password length
    if len(password) < 5:
        print("\n*******************************")
        print("*!!! Password is too short !!!*")
        print("*******************************\n")
        return False

    if len(password) > 10:
        print("\n*******************************")
        print("*!!! Password is too long !!!*")
        print("*******************************\n")
        return False

    return True


def move_user_details_to_top(username):
    with open("user_details.txt", "r+") as file:
        lines = file.readlines()
        file.seek(0)

        for line in lines:
            if username in line:
                file.write(line)

        for line in lines:
            if username not in line:
                file.write(line)

        file.truncate()


def login(name, password):
    users = read_user_data()
    if name in users and users[name]['password'] == password:
        move_user_details_to_top(name)  
        clear_terminal()
        print("\n**Logged In**")
        print("-----------------")
        print("**Welcome", users[name]['full_name'] + "**")
        print("Username:", name)
        print("-----------------")
        change_password_prompt(name, password)
    else:
        print("\n!!Username or Password is incorrect!!\n")
        start()


def admin_login(a_name, password):
    admins = read_admin_data()
    if a_name in admins and admins[a_name] == password:
        clear_terminal()
        print("\n** Logged In as Admin **\n")
        print("=======================")
        print("Welcome Admin", a_name)
        print("=======================")
        change_password_prompt(a_name, password, admin=True)
    else:
        print("\n!! Username or Password is incorrect !!\n")
        start()

def change_admin_password(username, current_password, new_password):
    admins = read_admin_data()

    if username in admins and admins[username] == current_password:
        admins[username] = new_password
        write_admin_data(admins)
        print("Password changed successfully.")
    else:
        print("Invalid username or password.")

def access2(opt):
    if opt == "1":
        sign_up()
        subprocess.run(["python", "homepage.py"])

    elif opt == "2":
        clear_terminal()
        print("========== LOG IN ==========")
        name = input("Enter your username: ")
        password = input("Enter your password: ")
        login(name, password)
        subprocess.run(["python", "homepage.py"])
    elif opt == "3":
        clear_terminal()
        print("========== ADMIN LOG IN ==========")
        a_name = input("Enter admin username: ")
        password = input("Enter admin password: ")
        admin_login(a_name, password)
        subprocess.run(["python", "homepage_admin.py"])
    else:
        print("\n!!Please enter valid options!!\n")
        return start()

def book():
    # Booking 
    pass

start()



