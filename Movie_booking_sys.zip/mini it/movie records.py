import os
import subprocess

def read_movies():
    with open("movie_records.txt", "r") as file:
        movies = file.read().splitlines()
    return movies

def write_movies(movies):
    with open("movie_records.txt", "w") as file:
        file.write("\n".join(movies))

def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

def print_movies():
    clear_screen()
    movies = read_movies()
    print("Movies")
    print("======")
    print("")
    for movie in movies:
        print("- " + movie.upper())

def remove_movie():
    movie_to_remove = input("Enter the name of the movie to remove: ")
    movies = read_movies()
    while movie_to_remove not in movies:
        print("Movie not found. Please try again.")
        movie_to_remove = input("Enter the name of the movie to remove: ")
    movies.remove(movie_to_remove)
    write_movies(movies)
    print("Movie removed successfully.")

def add_movie():
    clear_screen()
    while True:
        print("")
        new_movie = input("Enter a new movie (Enter 'K' to display updated record, Enter 'Q' to exit): ")
        if new_movie.lower() == "k":
            print_movies()
        elif new_movie.lower() == "q":
            subprocess.run(["python", "homepage_admin.py"])
        else:
            movies = read_movies()
            movies.append(new_movie)
            write_movies(movies)
            print("Movie added successfully.")

clear_screen()
print("Welcome to Stargaze Cinema")
print_movies()

while True:
    print("")
    action = input("Enter 'R' to remove a movie, Enter 'C' to continue: ")
    if action.lower() == "r":
        remove_movie()
    elif action.lower() == "c":
        add_movie()
    else:
        print("Invalid action. Please try again.")

        print("Thank you for using Stargaze Cinema!")
